-- DROP FUNCTION adempiere.z_sppa_select_f(int4, int4, int4, timestamp, timestamp);

CREATE OR REPLACE FUNCTION adempiere.z_sppa_select_f(clientid integer, orgid integer, orgdepoid integer, datefrom timestamp without time zone, dateto timestamp without time zone)
 RETURNS TABLE(ad_client_id integer, ad_org_id integer, depoid integer, depo character varying, documentno character varying, c_order_id integer, exsppa character varying, dateordered date, description character varying, isfinalcatching character varying, c_bpartner_id integer, z_warehouse_est_id integer, m_warehouse_id integer, z_project_est_id integer, c_project_id integer, totalamount integer, docstatus character varying, z_qty_ekor_est integer, z_abw_est integer, z_qty_kg_est integer, z_pricelist_estimasi integer, discountamtest integer, z_harga_pricelist_est integer, alasandiskonest integer, z_harga_estimasi integer, z_qty_ekor_real integer, z_abw_real integer, qtyentered integer, pricelist integer, discountamt integer, priceentered integer, z_tbl_alasandiskon_id integer, z_harga_realisasi integer, descline character varying, z_document_status character varying, kodecust character varying, updated date, z_catching_date date, tglinptrealisasi date, z_printed date, noplat character varying, sisa_stock integer)
 LANGUAGE plpgsql
AS $function$

declare
	rec_sppa record;

begin
	for rec_sppa in (
			 SELECT co.ad_client_id,
			    aoin.parent_org_id as ad_org_id,
			    org.ad_org_id AS depoid,
			    org.name AS depo,
			    co.documentno,
			    co.c_order_id,
			    co.poreference AS exsppa,
			    co.dateordered,
			    co.description,
			    co.isfinalcatching,
			    co.c_bpartner_id,
			    co.z_warehouse_est_id,
			    co.m_warehouse_id,
			    co.z_project_est_id,
			    co.c_project_id,
			    co.grandtotal AS totalamount,
			    co.docstatus,
			    corl.z_qty_ekor_est,
			    corl.z_abw_est,
			    corl.z_qty_kg_est,
			    corl.z_pricelist_estimasi,
			    corl.discountamtest,
			    corl.z_harga_pricelist_est,
			    corl.alasandiskonest,
			    corl.z_harga_estimasi,
			    corl.z_qty_ekor_real,
			    corl.z_abw_real,
			    corl.qtyentered,
			    corl.pricelist,
			    corl.discountamt,
			    corl.priceentered,
			    corl.z_tbl_alasandiskon_id,
			    corl.z_harga_realisasi,
			    corl.description AS descline,
			        CASE
			            WHEN (co.docstatus = ANY (ARRAY['IP'::bpchar, 'AP'::bpchar])) AND (( SELECT awp.created
			               FROM ad_wf_process awp
			                 JOIN ad_wf_activity awa ON awp.ad_wf_process_id = awa.ad_wf_process_id
			                 JOIN ad_wf_node awn ON awa.ad_wf_node_id = awn.ad_wf_node_id
			              WHERE awp.record_id = co.c_order_id AND awp.ad_table_id = 259::numeric AND lower(awn.name::text) ~~ '%verify realisasi%'::text AND awa.wfstate ~~ 'CC'::text
			              ORDER BY awp.created DESC
			             LIMIT 1)) IS NOT NULL THEN '(Menunggu Approval)'::character varying
			            ELSE
			            CASE
			                WHEN co.z_document_status::text ~~ '%(Menunggu Realisasi)%'::text OR co.z_document_status::text ~~ '%(Menunggu Print)%'::text THEN co.z_document_status
			                ELSE NULL::character varying
			            END
			        END AS z_document_status,
			    cb.value AS kodecust,
			    co.updated,
			    co.z_catching_date,
			    ( SELECT ac.updated
			           FROM ad_changelog ac
			          WHERE ac.ad_table_id = '259'::numeric AND ac.newvalue::text ~~ 'CO'::text AND ac.record_id = co.c_order_id
			          ORDER BY ac.updated DESC
			         LIMIT 1) AS tglinptrealisasi,
			    co.z_printed,
			    corl.z_lokasi AS noplat,
			    co.qtyonhand AS sisa_stock
			   FROM c_order co
			     JOIN c_doctype cd ON cd.c_doctype_id = co.c_doctypetarget_id
			     LEFT JOIN c_orderline corl ON co.c_order_id = corl.c_order_id
			     LEFT JOIN ad_org org ON co.ad_org_id = org.ad_org_id
			     LEFT JOIN ad_orginfo aoin ON org.ad_org_id = aoin.ad_org_id
			     LEFT JOIN c_bpartner cb ON co.c_bpartner_id = cb.c_bpartner_id
			  WHERE (cd.c_doctype_id IN ( SELECT zpn.c_doctype_id
			           FROM z_parameter_reporting zpr
			             JOIN z_pr_notapemberitahuan zpn ON zpr.z_parameter_reporting_id = zpn.z_parameter_reporting_id
			          WHERE zpr.name::text ~~ 'DocTypeSPPA'::text))
			  and co.ad_client_id = clientid
			  and aoin.parent_org_id = orgid
			  and org.ad_org_id = orgdepoid
			  and co.dateordered between datefrom and dateto
		)
	
	loop
		ad_client_id := rec_sppa.ad_client_id;
	    ad_org_id := rec_sppa.ad_org_id;
	    depoid := rec_sppa.depoid;
	    depo := rec_sppa.depo;
	    documentno := rec_sppa.documentno;
	    c_order_id := rec_sppa.c_order_id;
	    exsppa := rec_sppa.exsppa;
	    dateordered := rec_sppa.dateordered;
	    description := rec_sppa.description;
	    isfinalcatching := rec_sppa.isfinalcatching;
	    c_bpartner_id := rec_sppa.c_bpartner_id;
	    z_warehouse_est_id := rec_sppa.z_warehouse_est_id;
	    m_warehouse_id := rec_sppa.m_warehouse_id;
	    z_project_est_id := rec_sppa.z_project_est_id;
	    c_project_id := rec_sppa.c_project_id;
	    totalamount := rec_sppa.totalamount;
	    docstatus := rec_sppa.docstatus;
	    z_qty_ekor_est := rec_sppa.z_qty_ekor_est;
	    z_abw_est := rec_sppa.z_abw_est;
	    z_qty_kg_est := rec_sppa.z_qty_kg_est;
	    z_pricelist_estimasi := rec_sppa.z_pricelist_estimasi;
	    discountamtest := rec_sppa.discountamtest;
	    z_harga_pricelist_est := rec_sppa.z_harga_pricelist_est;
	    alasandiskonest := rec_sppa.alasandiskonest;
	    z_harga_estimasi := rec_sppa.z_harga_estimasi;
	    z_qty_ekor_real := rec_sppa.z_qty_ekor_real;
	    z_abw_real := rec_sppa.z_abw_real;
	    qtyentered := rec_sppa.qtyentered;
	    pricelist := rec_sppa.pricelist;
	    discountamt := rec_sppa.discountamt;
	    priceentered := rec_sppa.priceentered;
	    z_tbl_alasandiskon_id := rec_sppa.z_tbl_alasandiskon_id;
	    z_harga_realisasi := rec_sppa.z_harga_realisasi;
	    descline := rec_sppa.descline;
	    z_document_status := rec_sppa.z_document_status;
	    kodecust := rec_sppa.kodecust;
	    updated := rec_sppa.updated;
	    z_catching_date := rec_sppa.z_catching_date;
	    tglinptrealisasi := rec_sppa.tglinptrealisasi;
	    z_printed := rec_sppa.z_printed;
	    noplat := rec_sppa.noplat;
	    sisa_stock := rec_sppa.sisa_stock;
	    
	    return next;
	end loop;
	
end;
$function$
;
