-- DROP FUNCTION adempiere.z_sppa_insert_f(int4, int4, int4, timestamp, timestamp, int4);

CREATE OR REPLACE FUNCTION adempiere.z_sppa_insert_f(clientid integer, orgid integer, orgdepoid integer, datefrom timestamp without time zone, dateto timestamp without time zone, usrid integer)
 RETURNS void
 LANGUAGE plpgsql
AS $function$

begin	
	delete from z_sppa_tbl
	where ad_client_id = clientid
	and ad_org_id = orgid
	and ad_org_id = orgdepoid;
	
	insert into z_sppa_tbl
	(
	select
		ad_client_id,
	    ad_org_id,
	    depoid,
	    depo,
	    documentno,
	    c_order_id,
	    exsppa,
	    dateordered,
	    description,
	    isfinalcatching,
	    c_bpartner_id,
	    z_warehouse_est_id,
	    m_warehouse_id,
	    z_project_est_id,
	    c_project_id,
	    totalamount,
	    docstatus,
	    z_qty_ekor_est,
	    z_abw_est,
	    z_qty_kg_est,
	    z_pricelist_estimasi,
	    discountamtest,
	    z_harga_pricelist_est,
	    alasandiskonest,
	    z_harga_estimasi,
	    z_qty_ekor_real,
	    z_abw_real,
	    qtyentered,
	    pricelist,
	    discountamt,
	    priceentered,
	    z_tbl_alasandiskon_id,
	    z_harga_realisasi,
	    descline,
	    z_document_status,
	    kodecust,
	    updated,
	    z_catching_date,
	    tglinptrealisasi,
	    z_printed,
	    noplat,
	    sisa_stock,
		usrid,
		current_timestamp
	    
	    from z_sppa_select_f(clientid::int, orgid::int, orgdepoid::int, datefrom::date, dateto::date)
	);
end;
$function$
;
